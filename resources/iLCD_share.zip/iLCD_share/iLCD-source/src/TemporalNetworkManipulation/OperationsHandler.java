package TemporalNetworkManipulation;

import TemporalNetworkManipulation.Operations.Operation;

public interface OperationsHandler {
	
	public void handle(Operation currentOperation);
	
}
